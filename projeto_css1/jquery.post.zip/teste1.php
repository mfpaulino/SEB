<!DOCTYPE HTML>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Tutorial jQuery Código Master</title>
  <script src="componentes/externos/jquery/dist/jquery.min.js"></script>
  <script src="script.js"></script>
</head>
<body>
  <input type="text" name="nome" id="nome" />
  <input type="text" name="email" id="email" />
  <input type="submit" value="Enviar dados" id="btnEnviarDados">

  <div id="result"></div>
</body>
</html>